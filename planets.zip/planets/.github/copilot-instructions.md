<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# Planet Explorer Game - Copilot Instructions

This is an educational HTML webapp designed for 6-7 year old children to learn about planets in our solar system.

## Project Structure
- `index.html` - Main HTML structure with drag-and-drop game interface
- `styles.css` - Fun, space-themed CSS with animations and responsive design
- `script.js` - Interactive JavaScript game logic with touch support

## Design Principles
- Child-friendly interface with large, colorful elements
- Fun space theme with twinkling stars background
- Simple drag-and-drop mechanics suitable for young children
- Educational content about planet characteristics
- Responsive design for various devices including tablets

## Key Features
- Drag-and-drop fact matching game
- Planet cards with visual representations
- Interactive scoring system
- Touch support for mobile devices
- Celebration animations for successful completion
- Reset functionality to replay the game

## Coding Guidelines
- Use semantic HTML for accessibility
- Implement smooth CSS animations and transitions
- Write clean, commented JavaScript
- Ensure cross-browser compatibility
- Maintain mobile-first responsive design
- Keep code simple and maintainable for educational purposes
